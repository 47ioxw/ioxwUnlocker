﻿using System;
using System.IO;
using System.Linq;
using System.Text.Json;
using System.Text.Json.Nodes;
using System.Diagnostics;
using System.Threading;
using System.Globalization;

class Program
{
    const string TargetPropertyName = "DFIntTaskSchedulerTargetFps";
    static int Main(string[] args)
    {
        Console.OutputEncoding = System.Text.Encoding.UTF8;
        Console.CursorVisible = true;
        Console.Clear();
        ShowCreditsBox();
        Console.WriteLine();
        Console.Write("> Press Enter to load FPS unlocker ");
        Console.ReadLine();
        Console.Clear();
        Console.WriteLine("=== i0xwUnlocker (console) ===");
        int targetFps = PromptForTargetFps();
        Console.WriteLine();
        Console.WriteLine("Press Enter to apply...");
        Console.ReadLine();
        Console.Clear();
        Console.WriteLine("Applying target FPS: " + targetFps);
        int checksTotal = 10;
        bool[] results = new bool[checksTotal];
        string[] labels = new string[checksTotal];
        int step = 0;
        int percent = 0;
        DrawProgress(percent);

        string versionsPath = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "Roblox", "Versions");
        labels[step] = "Checking Roblox Versions folder";
        results[step] = Directory.Exists(versionsPath);
        AnimatedStatus(labels[step], results[step], ref percent, ++step, checksTotal);

        string latestVersion = FindLatestVersionFolder(versionsPath);
        labels[step] = "Found latest Roblox version folder";
        results[step] = !string.IsNullOrEmpty(latestVersion);
        AnimatedStatus(labels[step], results[step], ref percent, ++step, checksTotal);
        if (!results[1]) FinishAndExit(results, "No Roblox versions found.", null);

        string settingsPath = Path.Combine(latestVersion, "ClientSettings", "ClientAppSettings.json");
        labels[step] = "ClientAppSettings.json exists";
        results[step] = File.Exists(settingsPath);
        AnimatedStatus(labels[step], results[step], ref percent, ++step, checksTotal);
        if (!results[2]) FinishAndExit(results, $"Settings file not found: {settingsPath}", null);

        labels[step] = "Settings file writable";
        results[step] = IsFileWritable(settingsPath);
        AnimatedStatus(labels[step], results[step], ref percent, ++step, checksTotal);

        string backupPath = null;
        bool backupOk = false;
        try
        {
            backupPath = CreateBackup(settingsPath);
            backupOk = File.Exists(backupPath);
        }
        catch
        {
            backupOk = false;
        }
        labels[step] = "Backup created";
        results[step] = backupOk;
        AnimatedStatus(labels[step], results[step], ref percent, ++step, checksTotal);

        JsonNode root = null;
        bool parsed = false;
        try
        {
            var jsonText = File.ReadAllText(settingsPath);
            root = JsonNode.Parse(jsonText, new JsonNodeOptions { PropertyNameCaseInsensitive = true });
            parsed = root != null;
        }
        catch
        {
            parsed = false;
        }
        labels[step] = "Parsed settings JSON";
        results[step] = parsed;
        AnimatedStatus(labels[step], results[step], ref percent, ++step, checksTotal);
        if (!parsed) FinishAndExit(results, "Failed to parse settings JSON.", backupPath);

        bool fpsPresent = TryGetPropertyValue(root, TargetPropertyName, out JsonNode currentNode, out string matchedKey);
        labels[step] = $"Settings FPS cap present ({(fpsPresent ? matchedKey : TargetPropertyName)})";
        results[step] = true;
        AnimatedStatus(labels[step], results[step], ref percent, ++step, checksTotal);
        if (fpsPresent) Console.WriteLine("    Current value: " + (currentNode?.ToJsonString() ?? "(null)"));

        bool changed = TrySetPropertyRecursive(root, TargetPropertyName, targetFps, out JsonNode previousValue);
        if (!changed && root is JsonObject ro) { ro[TargetPropertyName] = targetFps; changed = true; }
        labels[step] = "Updated JSON property in-memory";
        results[step] = changed;
        AnimatedStatus(labels[step], results[step], ref percent, ++step, checksTotal);

        bool saved = false;
        if (changed)
        {
            try
            {
                string tmp = settingsPath + ".tmp";
                var newJson = root.ToJsonString(new JsonSerializerOptions { WriteIndented = true });
                File.WriteAllText(tmp, newJson);
                File.Copy(tmp, settingsPath, overwrite: true);
                File.Delete(tmp);
                saved = true;
            }
            catch
            {
                saved = false;
            }
        }
        labels[step] = "Saved patched settings file";
        results[step] = saved;
        AnimatedStatus(labels[step], results[step], ref percent, ++step, checksTotal);

        var running = Process.GetProcessesByName("RobloxPlayerBeta").Concat(Process.GetProcessesByName("RobloxStudioBeta")).ToArray();
        labels[step] = "Roblox processes running (no running = success)";
        results[step] = running.Length == 0;
        AnimatedStatus(labels[step], results[step], ref percent, ++step, checksTotal);
        if (running.Length > 0) Console.WriteLine("    Running: " + string.Join(", ", running.Select(p => p.ProcessName)));

        Console.WriteLine();
        int success = results.Count(r => r);
        int fails = results.Length - success;
        if (fails == 0)
        {
            Console.ForegroundColor = ConsoleColor.DarkGreen;
            TypeWrite("All checks passed.", 6);
            Console.ResetColor();
        }
        else
        {
            Console.ForegroundColor = ConsoleColor.Red;
            TypeWrite($"{fails} check(s) failed.", 6);
            Console.ResetColor();
        }
        Console.WriteLine($" ({success}/{results.Length})");
        if (!string.IsNullOrEmpty(backupPath)) Console.WriteLine("Backup: " + backupPath);
        Console.WriteLine();

        if (running.Length > 0)
        {
            Console.Write("Would you like to restart Roblox now so the change takes effect? (y/N): ");
            var r = Console.ReadLine();
            if (!string.IsNullOrWhiteSpace(r) && r.Trim().Equals("y", StringComparison.OrdinalIgnoreCase))
            {
                foreach (var p in running)
                {
                    try { p.Kill(true); } catch { }
                }
                Thread.Sleep(600);
                TryStartRoblox(latestVersion);
                Console.WriteLine("Roblox restarted.");
            }
            else
            {
                Console.WriteLine("Reminder: restart Roblox for changes to take effect.");
            }
        }
        else
        {
            Console.Write("Roblox not running. Would you like to start it now? (y/N): ");
            var r = Console.ReadLine();
            if (!string.IsNullOrWhiteSpace(r) && r.Trim().Equals("y", StringComparison.OrdinalIgnoreCase))
            {
                TryStartRoblox(latestVersion);
                Console.WriteLine("Roblox started.");
            }
        }

        Console.WriteLine();
        Console.WriteLine("Completed. Console will close in 5 seconds...");
        Thread.Sleep(5000);
        return fails == 0 ? 0 : 1;
    }

    static void ShowCreditsBox()
    {
        string[] lines =
        {
            "@47ioxw",
            "github.com/47ioxw",
            "guns.lol/47ioxw"
        };
        int width = lines.Max(l => l.Length) + 4;
        string horiz = new string('═', width);
        Console.WriteLine("╔" + horiz + "╗");
        foreach (var l in lines)
        {
            Console.WriteLine("║  " + l.PadRight(width - 4) + "  ║");
        }
        Console.WriteLine("╚" + horiz + "╝");
    }

    static int PromptForTargetFps()
    {
        while (true)
        {
            Console.Write("What is your target fps? > ");
            var input = Console.ReadLine();
            if (string.IsNullOrWhiteSpace(input)) { Console.WriteLine("Please enter a numeric FPS value."); continue; }
            if (int.TryParse(input.Trim(), NumberStyles.Integer, CultureInfo.InvariantCulture, out int fps))
            {
                if (fps < 0) { Console.WriteLine("Please enter a non-negative integer."); continue; }
                return fps;
            }
            Console.WriteLine("Invalid number, try again.");
        }
    }

    static void DrawProgress(int percent)
    {
        int blocks = percent / 10;
        int total = 10;
        string bar = "[" + new string('#', blocks) + new string('.', total - blocks) + $"] {percent}%";
        Console.Write("\r" + bar.PadRight(30));
    }

    static void AnimatedStatus(string label, bool ok, ref int percent, int stepIndex, int totalSteps)
    {
        Console.WriteLine();
        string pre = ok ? "[+]" : "[-]";
        Console.Write(pre + " ");
        Console.ForegroundColor = ok ? ConsoleColor.DarkGreen : ConsoleColor.Red;
        TypeWrite(label, 7);
        Console.ResetColor();
        Console.WriteLine();
        int targetPercent = stepIndex * 100 / totalSteps;
        for (int p = percent; p <= targetPercent; p++)
        {
            DrawProgress(p);
            Thread.Sleep(8);
        }
        percent = targetPercent;
    }

    static void TypeWrite(string text, int ms)
    {
        foreach (var c in text)
        {
            Console.Write(c);
            Thread.Sleep(ms);
        }
    }

    static bool IsFileWritable(string path)
    {
        try
        {
            using (var fs = File.Open(path, FileMode.Open, FileAccess.ReadWrite, FileShare.None)) { }
            return true;
        }
        catch { return false; }
    }

    static string CreateBackup(string settingsPath)
    {
        string dir = Path.GetDirectoryName(settingsPath) ?? ".";
        string timestamp = DateTime.UtcNow.ToString("yyyyMMddHHmmss", CultureInfo.InvariantCulture);
        string backupPath = Path.Combine(dir, $"ClientAppSettings.json.bak.{timestamp}");
        File.Copy(settingsPath, backupPath, overwrite: false);
        return backupPath;
    }

    static bool TryGetPropertyValue(JsonNode root, string key, out JsonNode value, out string matchedKey)
    {
        value = null;
        matchedKey = null;
        if (root == null) return false;
        if (root is JsonObject obj)
        {
            foreach (var kv in obj)
            {
                if (string.Equals(kv.Key, key, StringComparison.OrdinalIgnoreCase))
                {
                    matchedKey = kv.Key;
                    value = kv.Value;
                    return true;
                }
                if (kv.Value != null && TryGetPropertyValue(kv.Value, key, out value, out matchedKey)) return true;
            }
            return false;
        }
        else if (root is JsonArray arr)
        {
            for (int i = 0; i < arr.Count; i++)
            {
                if (arr[i] != null && TryGetPropertyValue(arr[i], key, out value, out matchedKey)) return true;
            }
            return false;
        }
        return false;
    }

    static bool TrySetPropertyRecursive(JsonNode node, string key, int value, out JsonNode previousValue)
    {
        previousValue = null;
        if (node == null) return false;
        if (node is JsonObject obj)
        {
            if (obj.ContainsKey(key))
            {
                var existing = obj[key];
                previousValue = existing != null ? JsonNode.Parse(existing.ToJsonString()) : null;
                obj[key] = value;
                return true;
            }
            // FIX: Use obj.Keys property is not available, use obj instead
            var foundKey = obj.FirstOrDefault(kv => string.Equals(kv.Key, key, StringComparison.OrdinalIgnoreCase)).Key;
            if (foundKey != null)
            {
                var existing = obj[foundKey];
                previousValue = existing != null ? JsonNode.Parse(existing.ToJsonString()) : null;
                obj[foundKey] = value;
                return true;
            }
            foreach (var prop in obj)
            {
                if (prop.Value != null && TrySetPropertyRecursive(prop.Value, key, value, out previousValue)) return true;
            }
            return false;
        }
        else if (node is JsonArray arr)
        {
            for (int i = 0; i < arr.Count; i++)
            {
                if (arr[i] != null && TrySetPropertyRecursive(arr[i], key, value, out previousValue)) return true;
            }
            return false;
        }
        return false;
    }

    static string FindLatestVersionFolder(string root)
    {
        try
        {
            var dirs = Directory.GetDirectories(root)
                .Select(d =>
                {
                    var name = Path.GetFileName(d);
                    Version version = null;
                    if (Version.TryParse(name, out var v)) version = v;
                    return new { Path = d, Version = version, LastWrite = Directory.GetLastWriteTimeUtc(d) };
                })
                .OrderByDescending(x => x.Version != null)
                .ThenByDescending(x => x.Version ?? new Version(0, 0))
                .ThenByDescending(x => x.LastWrite)
                .ToArray();
            return dirs.FirstOrDefault()?.Path;
        }
        catch { return string.Empty; }
    }

    static void TryStartRoblox(string latestVersionFolder)
    {
        try
        {
            var exe = FindRobloxExecutable(latestVersionFolder);
            if (!string.IsNullOrEmpty(exe))
            {
                Process.Start(new ProcessStartInfo { FileName = exe, UseShellExecute = true });
            }
            else
            {
                Process.Start(new ProcessStartInfo { FileName = latestVersionFolder, UseShellExecute = true });
            }
        }
        catch { }
    }

    static string FindRobloxExecutable(string rootFolder)
    {
        try
        {
            var candidates = Directory.EnumerateFiles(rootFolder, "RobloxPlayerBeta.exe", SearchOption.AllDirectories).ToList();
            if (candidates.Count > 0) return candidates[0];
            candidates = Directory.EnumerateFiles(rootFolder, "RobloxStudioBeta.exe", SearchOption.AllDirectories).ToList();
            if (candidates.Count > 0) return candidates[0];
            candidates = Directory.EnumerateFiles(rootFolder, "Roblox*.exe", SearchOption.AllDirectories).ToList();
            if (candidates.Count > 0) return candidates[0];
        }
        catch { }
        return string.Empty;
    }

    static void FinishAndExit(bool[] results, string message, string backupPath)
    {
        Console.WriteLine();
        Console.Error.WriteLine(message);
        Console.WriteLine();
        int successCount = results.Count(r => r);
        int failCount = results.Length - successCount;
        Console.Write("Summary: ");
        if (failCount == 0)
        {
            Console.ForegroundColor = ConsoleColor.DarkGreen;
            Console.WriteLine("All checks passed.");
            Console.ResetColor();
        }
        else
        {
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine($"{failCount} check(s) failed.");
            Console.ResetColor();
        }
        if (!string.IsNullOrEmpty(backupPath)) Console.WriteLine("Backup: " + backupPath);
        Console.WriteLine("Closing in 5 seconds...");
        Thread.Sleep(5000);
        Environment.Exit(failCount == 0 ? 0 : 1);
    }
}